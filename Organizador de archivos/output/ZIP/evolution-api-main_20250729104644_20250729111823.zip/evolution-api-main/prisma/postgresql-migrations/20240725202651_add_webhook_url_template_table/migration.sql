-- AlterTable
ALTER TABLE "Template" ADD COLUMN     "webhookUrl" VARCHAR(500);
