-- AlterTable
ALTER TABLE "Instance" ADD COLUMN     "profileName" VARCHAR(100);
