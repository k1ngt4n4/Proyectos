-- AlterTable
ALTER TABLE "IntegrationSession" ADD COLUMN     "type" VARCHAR(100);
